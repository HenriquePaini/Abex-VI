from django.test import TestCase

# Create your tests here.


#<a href="{% if positivo %}{% url 'resultado' %}{% else %}{% url 'contato' %}{% endif %}"